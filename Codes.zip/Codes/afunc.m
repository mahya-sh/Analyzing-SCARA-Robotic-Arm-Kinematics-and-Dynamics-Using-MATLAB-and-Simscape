function A = afunc(i,a,b,th)
A=[a(i)*cos(th(i));a(i)*sin(th(i));b(i)];
end



