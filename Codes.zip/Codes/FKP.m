clc,clear
syms theta_dot theta  b1 theta2 theta3 b4 ...
      b1_dot theta2_dot theta3_dot b4_dot ...
      b1_ddot theta2_ddot  ...
     theta3_ddot b4_ddot;
a=[0,397.1,250.8,0];
b=[b1, 121, 80,b4];
alpha=[-pi/2,0,0,0];
th=[0,theta2,theta3,0];
Q1=round(Qfunc(1,th,alpha));
Q2=Qfunc(2,th,alpha);
Q3=Qfunc(3,th,alpha);
Q4=Qfunc(4,th,alpha);
Q=Q1*Q2*Q3*Q4;
a1=afunc(1,a,b,th);
a2=afunc(2,a,b,th);
a3=afunc(3,a,b,th);
a4=afunc(4,a,b,th);