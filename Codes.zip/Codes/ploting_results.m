clc
close all
TAUT = TAU';
figure()
%%
% Plot



plot(TAUT)

% Add title and labels as needed
title('Joints torque and force using Simscape and dynamic model')

% Add any other customization to the plot as needed

% Ensure plot visibility
drawnow
% title : 'joints torque and force using simscape and dynamic model'